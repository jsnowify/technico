"use client";

import { useRef } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import { useGSAP } from "@gsap/react";
import {
  gsap,
  Draggable,
  InertiaPlugin,
  prefersReducedMotion,
  supportsFinePointer,
} from "@/lib/gsap";
import { TRUSTED_BY } from "@/lib/constants";

/* ================================================================
   TRUSTED BY
   ================================================================
   Sits directly between Hero.tsx and HeroStats.tsx in app/page.tsx —
   same bg-black-bg as both, so it reads as a continuation of the
   hero rather than a new section starting.

   AUTOPLAY: a `gsap.ticker` callback nudges the track's x a little
   every frame (frame-rate independent via `deltaRatio`) and wraps it
   with `gsap.utils.wrap` once it's scrolled one loop-width, so the
   strip reads as an endless, continuous loop. `xRef` is the single
   source of truth for the track's position — both the ticker and
   Draggable's wrap modifier read/write through it, and the ticker
   skips writing to it entirely while a drag/throw is in progress (see
   DRAG below) so the two never fight over the same frame.

   SCROLL-DRIVEN DIRECTION, SPEED, AND TILT: a single scroll listener
   computes the page's scroll velocity and drives three things off it —
   which way the strip autoplays (scrolling down -> left, up -> right),
   a small capped speed boost on top of AUTOPLAY_SPEED that eases back
   down once scrolling slows or stops, and a small capped skewY tilt on
   each card (not the whole track, so cards near the ends don't shear
   more than ones in the middle) that eases back to flat the same way.

   DRAG + INERTIA VIA A WRAP MODIFIER — Draggable's `modifiers` option
   rewrites the x value right before each render, during both the live
   drag AND the post-release inertia glide, into `wrap(-loopWidth, 0)`.
   That's what makes the drag feel endless: keep dragging left past the
   last logo and it just wraps back to the first one, same as the
   autoplay direction. `loopWidth` is measured once from the mounted
   track's real `scrollWidth / CLONE_COUNT` (TRACK below is TRUSTED_BY
   repeated CLONE_COUNT times — more than the minimum 2 clones so a
   hard drag/flick always has buffer left to wrap into instead of
   momentarily showing empty space) rather than hard-coded, so it stays
   correct if the tile size, gap, or logo count ever changes.
   `this.isThrowing` (a real Draggable instance flag) is what tells
   onDragEnd whether InertiaPlugin is still gliding — autoplay only
   picks back up once the glide actually finishes (onThrowComplete),
   not the instant the pointer lifts, otherwise the ticker and the
   inertia glide would both be writing to `x` in the same frame and
   fight each other. That fighting is what made the very first drag
   pass feel rough — this version avoids it by only ever having ONE
   writer of `x` active at a time (ticker OR Draggable/InertiaPlugin,
   never both), and by ramping autoplay back in gradually
   (AUTOPLAY_RAMP_SECONDS) rather than snapping straight to full speed
   the instant control returns to it.

   That still leaves one gap: nothing stops a hard, fast flick from
   out-running however much buffer the clones provide, however
   generous. So `inertia.x` isn't just `true` — it's a function that
   clamps InertiaPlugin's own natural (velocity-based) end value to at
   most `MAX_THROW_LOOPS` loop-widths from wherever the gesture started
   (`pressXRef`, captured `onPress`). A hard flick still glides further
   and longer than a gentle one — it's just capped at a distance we
   know is always safely inside the buffer.

   Cursor-following "TRUSTED BY" pill is unchanged from before: a
   `gsap.quickTo` trailing-pointer + enter/leave scale-and-fade
   mechanism, driven by the wrapper's pointer events since this one
   constant label doesn't care which logo it's over.

   LOGOS ARE PLAIN <img>, NOT next/image: TRUSTED_BY's URLs are
   external Cloudinary assets, and this project's next.config isn't
   part of this component tree to confirm a matching `remotePatterns`
   entry exists for that host. `draggable={false}` on each <img> stops
   the browser's own native "drag this image out" affordance from
   fighting with Draggable's pointer handling.
   ================================================================ */

// Rendered 6x back-to-back rather than just twice. With only two
// copies there's exactly one loop-width of buffer past the wrap point
// — fine for the slow, steady autoplay creep, but a manual drag/flick
// can yank the strip past that single buffer in one throw, and for a
// frame or two there's nothing left to render (a flash of empty
// space). 6 copies gives a hard, fast flick (see MAX_THROW_LOOPS
// below) enough room that its natural, uncapped glide distance almost
// never needs truncating, without the DOM/image cost of the original
// 8x.
const CLONE_COUNT = 6;
const TRACK = Array.from({ length: CLONE_COUNT }, () => TRUSTED_BY).flat();

// Autoplay speed in px/sec, independent of frame rate — tune this one
// number to speed up/slow down the base loop (before the scroll-driven
// boost below is added on top).
const AUTOPLAY_SPEED = 70;

// Seconds for autoplay to ease from a dead stop back up to
// AUTOPLAY_SPEED after a drag/throw hands control back to it. Without
// this, the instant a drag/throw ends the ticker would jump straight
// to full cruising speed — a real, if small, discontinuity right when
// the strip was at (or near) rest from the throw decelerating. Ramping
// it in is what makes "gesture ends -> autoplay resumes" read as one
// continuous motion instead of a stop followed by a jump.
const AUTOPLAY_RAMP_SECONDS = 0.6;

// How far a single throw (drag + release momentum) is allowed to carry
// the strip, as a multiple of one loop-width. Capping the throw itself,
// the way a well-behaved native scroll view does, means the strip can
// never travel further in one gesture than we've actually got
// buffered, no matter how fast or long the swipe was.
const MAX_THROW_LOOPS = 3;

// InertiaPlugin's own friction dial: default is 1000, higher = the
// velocity-based end value it computes decays faster (a shorter,
// stiffer glide). Lower gives a longer, weightier coast after release.
const THROW_RESISTANCE = 400;

// Extra speed on top of AUTOPLAY_SPEED, driven by how fast the page is
// being scrolled. Capped so a wild, hard scroll can only ever
// double-ish the base speed rather than sending the strip flying.
// Decays back toward 0 every frame so the marquee eases back to its
// normal speed shortly after scrolling stops.
const SCROLL_BOOST_CAP = 160;
const SCROLL_VELOCITY_DIVISOR = 6;

// Degrees — a small, subtle tilt on each card, also driven by scroll
// velocity. Kept low on purpose: a light wobble, not a dramatic warp.
const MAX_TILT = 6;
const TILT_VELOCITY_DIVISOR = 320;

export default function TrustedBy() {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const pillRef = useRef<HTMLSpanElement>(null);

  const movePillXRef = useRef<((value: number) => void) | null>(null);
  const movePillYRef = useRef<((value: number) => void) | null>(null);
  const setPillScaleXRef = useRef<((value: number) => void) | null>(null);
  const setPillScaleYRef = useRef<((value: number) => void) | null>(null);
  const setPillOpacityRef = useRef<((value: number) => void) | null>(null);

  const pendingPointerRef = useRef<{ x: number; y: number } | null>(null);
  const followCursorRafRef = useRef<number | null>(null);

  // Autoplay/drag state. `xRef` is the single source of truth for the
  // track's horizontal position, always kept inside (-loopWidth, 0] —
  // both the ticker and Draggable's wrap modifier read/write through
  // it.
  const loopWidthRef = useRef(0);
  const xRef = useRef(0);
  const isDraggingRef = useRef(false);
  // Current effective autoplay speed factor (0 -> 1) — 0 while
  // dragging/throwing, and eased back up toward 1 once control returns
  // to autoplay. Reset to 0 every frame a drag/throw is in progress so
  // a resume always ramps up fresh, never picks up mid-ramp from a
  // stale value.
  const autoplayRampRef = useRef(0);
  // x at the instant the pointer goes down — the throw-distance clamp
  // measures "how far did this one fling move it" relative to this,
  // not relative to 0.
  const pressXRef = useRef(0);

  useGSAP(() => {
    const track = trackRef.current;
    if (!track || prefersReducedMotion) return;

    loopWidthRef.current = Math.round(track.scrollWidth / CLONE_COUNT);
    const wrap = gsap.utils.wrap(-loopWidthRef.current, 0);

    // Direction flips with the page's scroll direction: scrolling down
    // keeps the strip moving left (the default), scrolling up sends it
    // right.
    const directionRef = { current: 1 };
    const boostRef = { current: 0 };
    const clampBoost = gsap.utils.clamp(0, SCROLL_BOOST_CAP);

    const cards = Array.from(track.children) as HTMLElement[];
    const clampSkew = gsap.utils.clamp(-MAX_TILT, MAX_TILT);
    const skewRef = { current: 0 };
    const setSkew = gsap.quickTo(cards, "skewY", {
      duration: 0.6,
      ease: "power3",
    });

    let lastScrollY = window.scrollY;
    let lastTime = performance.now();
    const onScroll = () => {
      const now = performance.now();
      const currentY = window.scrollY;
      const deltaY = currentY - lastScrollY;
      const deltaT = Math.max(now - lastTime, 1);
      const velocity = (deltaY / deltaT) * 1000; // px/sec

      if (velocity > 0) directionRef.current = 1;
      else if (velocity < 0) directionRef.current = -1;

      // Only grow from a faster scroll; let the per-frame decay below
      // shrink it back down. Prevents a slower scroll event landing
      // right after a fast one from cutting the boost/tilt short early.
      const incomingBoost = clampBoost(
        Math.abs(velocity) / SCROLL_VELOCITY_DIVISOR,
      );
      boostRef.current = Math.max(boostRef.current, incomingBoost);

      const skew = clampSkew(velocity / -TILT_VELOCITY_DIVISOR);
      if (Math.abs(skew) > Math.abs(skewRef.current)) {
        skewRef.current = skew;
        setSkew(skew);
      }

      lastScrollY = currentY;
      lastTime = now;
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    const tick = () => {
      const dr = gsap.ticker.deltaRatio(60);

      // Decay boost/tilt regardless of drag state so they don't hang
      // around mid-drag and then suddenly resume once released.
      boostRef.current *= 0.85;
      if (Math.abs(skewRef.current) > 0.02) {
        skewRef.current *= 0.9;
        setSkew(skewRef.current);
      } else if (skewRef.current !== 0) {
        skewRef.current = 0;
        setSkew(0);
      }

      if (isDraggingRef.current) {
        // Kept at 0 for the whole gesture so the next resume always
        // ramps up from a clean stop, never from wherever a previous
        // ramp happened to leave off. Draggable/InertiaPlugin owns
        // `x` for the whole gesture — this callback must not touch it.
        autoplayRampRef.current = 0;
        return;
      }

      // Exponential ease toward full speed, frame-rate independent via
      // deltaRatio. ~0.6s to reach effectively full speed.
      const rampRate = 1 / (AUTOPLAY_RAMP_SECONDS * 60);
      autoplayRampRef.current += (1 - autoplayRampRef.current) * rampRate * dr;

      const speed =
        (AUTOPLAY_SPEED + boostRef.current) * autoplayRampRef.current;
      xRef.current = wrap(
        xRef.current - speed * directionRef.current * (dr / 60),
      );
      gsap.set(track, { x: Math.round(xRef.current) });
    };
    gsap.ticker.add(tick);

    let draggable: Draggable | null = null;
    if (!prefersReducedMotion) {
      // Set once, up front, rather than only during onPress: promoting
      // to a compositor layer on the fly (right as the user grabs it)
      // is exactly the kind of one-time cost that shows up as a hitch
      // on the very first pixel of movement.
      track.style.willChange = "transform";
      [draggable] = Draggable.create(track, {
        type: "x",
        inertia: {
          resistance: THROW_RESISTANCE,
          x: (value: number) =>
            gsap.utils.clamp(
              pressXRef.current - loopWidthRef.current * MAX_THROW_LOOPS,
              pressXRef.current + loopWidthRef.current * MAX_THROW_LOOPS,
              value,
            ),
          duration: { max: 3.5 },
        },
        allowNativeTouchScrolling: true,
        // Rewrites x into (-loopWidth, 0] right before every render,
        // during both the live drag and the post-release inertia
        // glide. Left as sub-pixel (not rounded): rounding on every
        // frame introduces a visible stutter right at the start of a
        // drag.
        modifiers: { x: (value: number) => wrap(value) },
        onPress: function (this: Draggable) {
          isDraggingRef.current = true;
          pressXRef.current = Number(gsap.getProperty(track, "x")) || 0;
        },
        onDragEnd: function (this: Draggable) {
          // Still gliding via InertiaPlugin -> onThrowComplete (below)
          // is what actually hands control back, not this callback.
          if (!this.isThrowing) {
            xRef.current = Number(gsap.getProperty(track, "x")) || 0;
            isDraggingRef.current = false;
          }
        },
        onThrowComplete: () => {
          xRef.current = Number(gsap.getProperty(track, "x")) || 0;
          isDraggingRef.current = false;
        },
      });
    }

    return () => {
      gsap.ticker.remove(tick);
      window.removeEventListener("scroll", onScroll);
      gsap.killTweensOf(cards);
      draggable?.kill();
      track.style.willChange = "auto";
    };
  }, []);

  const setPillScale = (value: number) => {
    setPillScaleXRef.current?.(value);
    setPillScaleYRef.current?.(value);
  };

  const clampPillPosition = (x: number, y: number, wrapperRect: DOMRect) => {
    const pill = pillRef.current;
    if (!pill) return { x, y };

    const halfWidth = pill.offsetWidth / 2;
    const halfHeight = pill.offsetHeight / 2;

    return {
      x: Math.min(Math.max(x, halfWidth), wrapperRect.width - halfWidth),
      y: Math.min(Math.max(y, halfHeight), wrapperRect.height - halfHeight),
    };
  };

  useGSAP(() => {
    const pill = pillRef.current;
    if (!pill || prefersReducedMotion || !supportsFinePointer) return;

    gsap.set(pill, {
      xPercent: -50,
      yPercent: -50,
      scaleX: 0.4,
      scaleY: 0.4,
      opacity: 0,
    });
    pill.style.willChange = "transform";

    movePillXRef.current = gsap.quickTo(pill, "x", {
      duration: 0.5,
      ease: "power3.out",
    });
    movePillYRef.current = gsap.quickTo(pill, "y", {
      duration: 0.5,
      ease: "power3.out",
    });
    setPillScaleXRef.current = gsap.quickTo(pill, "scaleX", {
      duration: 0.55,
      ease: "power3.out",
    });
    setPillScaleYRef.current = gsap.quickTo(pill, "scaleY", {
      duration: 0.55,
      ease: "power3.out",
    });
    setPillOpacityRef.current = gsap.quickTo(pill, "opacity", {
      duration: 0.18,
      ease: "power1.out",
    });

    return () => {
      movePillXRef.current = null;
      movePillYRef.current = null;
      setPillScaleXRef.current = null;
      setPillScaleYRef.current = null;
      setPillOpacityRef.current = null;
      gsap.killTweensOf(pill);
      pill.style.willChange = "auto";
      if (followCursorRafRef.current !== null) {
        cancelAnimationFrame(followCursorRafRef.current);
        followCursorRafRef.current = null;
      }
      pendingPointerRef.current = null;
    };
  }, []);

  const handlePointerEnter = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (
      prefersReducedMotion ||
      !supportsFinePointer ||
      event.pointerType !== "mouse" ||
      !wrapperRef.current ||
      !pillRef.current
    ) {
      return;
    }

    const rect = wrapperRef.current.getBoundingClientRect();
    const { x, y } = clampPillPosition(
      event.clientX - rect.left,
      event.clientY - rect.top,
      rect,
    );
    gsap.set(pillRef.current, { x, y });
    setPillScale(1);
    setPillOpacityRef.current?.(1);
  };

  const handlePointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (
      prefersReducedMotion ||
      !supportsFinePointer ||
      event.pointerType !== "mouse"
    ) {
      return;
    }

    pendingPointerRef.current = { x: event.clientX, y: event.clientY };
    if (followCursorRafRef.current !== null) return;

    followCursorRafRef.current = requestAnimationFrame(() => {
      followCursorRafRef.current = null;

      const pending = pendingPointerRef.current;
      if (
        !pending ||
        !wrapperRef.current ||
        !movePillXRef.current ||
        !movePillYRef.current
      ) {
        return;
      }

      const rect = wrapperRef.current.getBoundingClientRect();
      const { x, y } = clampPillPosition(
        pending.x - rect.left,
        pending.y - rect.top,
        rect,
      );
      movePillXRef.current(x);
      movePillYRef.current(y);
    });
  };

  const handlePointerLeave = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (
      prefersReducedMotion ||
      !supportsFinePointer ||
      event.pointerType !== "mouse"
    ) {
      return;
    }

    setPillScale(0.4);
    setPillOpacityRef.current?.(0);
  };

  return (
    <section className="bg-black-bg">
      <div
        ref={wrapperRef}
        onPointerEnter={handlePointerEnter}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
        className="relative overflow-hidden py-14 sm:py-16 md:py-20"
        style={{
          WebkitMaskImage:
            "linear-gradient(to right, transparent, black 10%, black 90%, transparent)",
          maskImage:
            "linear-gradient(to right, transparent, black 10%, black 90%, transparent)",
        }}
      >
        <div
          ref={trackRef}
          className="flex w-max cursor-grab items-center [-webkit-user-select:none] select-none active:cursor-grabbing"
          style={{ touchAction: "pan-y" }}
        >
          {TRACK.map((brand, i) => (
            <div
              key={i}
              aria-hidden={i >= TRUSTED_BY.length || undefined}
              className="mr-8 flex aspect-square h-36 shrink-0 items-center justify-center border border-white/10 bg-white/[0.03] p-6 sm:h-48 sm:p-8 md:mr-12 md:h-60 md:p-10"
            >
              {/* No loading="lazy" here on purpose: this track gets
                  moved by transform (autoplay + drag), not native
                  scroll, so the browser's lazy-load heuristic has no
                  reliable signal for "about to be visible" the way it
                  does for a real scroll container. A hard flick can
                  reveal a clone the browser never bothered to
                  fetch/decode yet, and that decode landing mid-gesture
                  is exactly the kind of one-frame stall that reads as
                  the drag stuttering. These are small logo marks, not
                  hero images, so loading everything up front is cheap. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={brand.logo}
                alt=""
                decoding="async"
                draggable={false}
                className="h-full w-full object-contain"
              />
            </div>
          ))}
        </div>

        {/* Cursor-following "Trusted by" pill — see doc comment above.
            pointer-events-none so it never steals the hover/move
            events it depends on off the wrapper itself. */}
        <span
          ref={pillRef}
          className="pointer-events-none absolute top-0 left-0 z-10 rounded-[3px] bg-white px-4 py-2 font-mono text-xs tracking-[0.14em] text-black-text uppercase whitespace-nowrap opacity-0"
        >
          Trusted by
        </span>
      </div>
    </section>
  );
}
