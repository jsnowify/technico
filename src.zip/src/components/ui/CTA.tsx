"use client";

import { useRef, type ReactNode } from "react";
import { useGSAP } from "@gsap/react";
import Button from "@/components/ui/Button";
import { gsap, Draggable, prefersReducedMotion } from "@/lib/gsap";

/**
 * Cta
 * -----------
 * Stripped back to match the client's stat-card reference exactly:
 * a flat, solid dark panel, square corners (no border-radius), a
 * dotted border, and a small solid white triangle "flag" sitting on
 * top of the border at each of the four corners -- copied straight
 * from the reference screenshot's corner detail. A small monospace
 * label is pinned top-left, and the headline is chunky/heavy-weight
 * to do the same visual job as the "98.7%" numeral in the
 * reference -- the one bold thing on the card. Everything the
 * previous sci-fi pass added on top of the panel (nebula glow,
 * grain texture, the cut-corner peel, the crosshair corner marks)
 * is gone; this version has exactly one visual idea -- the dotted
 * border + corner flags -- reused from the other stat-card panels
 * on the page, so the CTA reads as part of the same system instead
 * of a separate, busier treatment.
 *
 * The reticle beside the button is the one thing kept from the
 * previous version: a small continuous spin plus GSAP
 * Draggable/InertiaPlugin toy-physics, both skipped under reduced
 * motion, giving the card one quiet, optional interaction without
 * competing with the headline.
 *
 * Copy defaults, the CtaLink shape, and the `wide` prop are
 * unchanged so existing call sites (AboutStory.tsx,
 * AboutBusinessMarketing.tsx, Qualify.tsx) keep working without
 * edits. The new `eyebrow` prop is optional and defaults to
 * "LET'S TALK", matching the "01 / SYSTEM RELIABILITY" corner-label
 * pattern from the stat cards.
 */

interface CtaLink {
  label: string;
  href: string;
}

interface CtaProps {
  /** Usually a plain string, but accepts JSX (e.g. a manual <br />)
   *  for call sites that need a specific line break in the headline
   *  rather than relying on natural wrapping. */
  title?: ReactNode;
  description?: string;
  cta?: CtaLink;
  className?: string;
  /** Widens the description column past the default `max-w-sm` (built
   *  for a short one-line blurb) to `max-w-md sm:max-w-lg`, for call
   *  sites whose copy runs to a couple of sentences instead. */
  wide?: boolean;
  /** Small monospace label pinned to the top-left corner, matching
   *  the "01 / SYSTEM RELIABILITY" pattern on the stat cards. */
  eyebrow?: string;
}

export default function Cta({
  title = "We go the extra mile to help you",
  description = "Fulfill your business plans with targeted digital marketing strategies. Partner with us today and see competitive results.",
  cta = { label: "Book A Call", href: "#" },
  className = "",
  wide = false,
  eyebrow = "LET'S TALK",
}: CtaProps) {
  const reticleRef = useRef<SVGSVGElement>(null);

  useGSAP(() => {
    if (!reticleRef.current || prefersReducedMotion) return;
    const el = reticleRef.current;

    gsap.to(el, {
      rotation: 360,
      duration: 14,
      repeat: -1,
      ease: "none",
      transformOrigin: "50% 50%",
    });

    const [draggable] = Draggable.create(el, {
      type: "x,y",
      inertia: true,
      bounds: { minX: -50, maxX: 50, minY: -50, maxY: 50 },
      edgeResistance: 1,
      onPress() {
        gsap.to(el, { scale: 1.1, duration: 0.15 });
      },
      onRelease() {
        gsap.to(el, {
          x: 0,
          y: 0,
          scale: 1,
          duration: 0.6,
          ease: "elastic.out(1, 0.45)",
        });
      },
    });

    return () => {
      draggable.kill();
    };
  }, []);

  return (
    <section className={`px-4 py-16 sm:px-6 sm:py-20 md:py-24 ${className}`}>
      <div className="relative mx-auto max-w-6xl border border-dotted border-white/25 bg-[#14141A] px-8 py-12 sm:px-12 sm:py-14 md:px-16 md:py-16">
        {/* Corner flags -- a small solid white triangle at each of
            the four corners, sitting on top of the dotted border,
            matching the reference's stat-card corner mark. */}
        <span
          aria-hidden="true"
          className="absolute top-0 left-0 h-3 w-3 bg-white sm:h-3.5 sm:w-3.5"
          style={{ clipPath: "polygon(0 0, 100% 0, 0 100%)" }}
        />
        <span
          aria-hidden="true"
          className="absolute top-0 right-0 h-3 w-3 bg-white sm:h-3.5 sm:w-3.5"
          style={{ clipPath: "polygon(0 0, 100% 0, 100% 100%)" }}
        />
        <span
          aria-hidden="true"
          className="absolute bottom-0 left-0 h-3 w-3 bg-white sm:h-3.5 sm:w-3.5"
          style={{ clipPath: "polygon(0 0, 0 100%, 100% 100%)" }}
        />
        <span
          aria-hidden="true"
          className="absolute right-0 bottom-0 h-3 w-3 bg-white sm:h-3.5 sm:w-3.5"
          style={{ clipPath: "polygon(100% 0, 100% 100%, 0 100%)" }}
        />

        <span className="font-mono text-xs tracking-[-0.02em] text-white/45 uppercase sm:text-sm">
          {eyebrow}
        </span>

        <div className="mt-8 flex flex-col items-start justify-between gap-10 sm:mt-10 lg:flex-row lg:items-end lg:gap-8">
          <div className="max-w-2xl">
            <h2 className="h2-section leading-[1.15] font-medium tracking-heading text-white">
              {title}
            </h2>

            <p
              className={`body-copy mt-5 leading-[1.6] tracking-[-0.02em] text-white uppercase sm:mt-6 ${
                wide ? "max-w-md sm:max-w-lg" : "max-w-sm"
              }`}
            >
              {description}
            </p>
          </div>

          <div className="flex max-w-full shrink-0 items-center gap-4">
            <Button to={cta.href} variant="purple-fill" size="lg">
              {cta.label}
            </Button>
            <svg
              ref={reticleRef}
              className="hidden h-7 w-7 shrink-0 cursor-grab touch-none text-white/50 [will-change:transform] active:cursor-grabbing sm:block sm:h-8 sm:w-8"
              viewBox="0 0 37 37"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M0 0C0 4.89546 1.94417 9.59041 5.40594 13.0517C8.86771 16.5135 13.5626 18.4581 18.4581 18.4581V0L0 0ZM18.4581 18.4581L36.9166 18.4581V0C32.0211 0 27.3258 1.94464 23.864 5.40593C20.4023 8.8677 18.4581 13.5622 18.4581 18.4581ZM18.4581 18.4581L18.4581 36.9161H36.9166C36.9166 32.0208 34.9724 27.3258 31.5106 23.864C28.0489 20.4028 23.3534 18.4581 18.4581 18.4581ZM18.4581 18.4581H0L0 36.9161C4.89546 36.9161 9.59086 34.9714 13.0526 31.5102C16.5144 28.0484 18.4581 23.3535 18.4581 18.4581Z"
                fill="currentColor"
              />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
