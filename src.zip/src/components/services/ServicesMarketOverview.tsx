import Link from "next/link";
import Image from "next/image";
import TextRevealBlock from "@/components/motion/TextRevealBlock";
import GlossyButton from "@/components/ui/GlossyButton";

/* ================================================================
   SERVICES MARKET OVERVIEW
   ================================================================
   Long-form supporting copy for /services, placed below the
   services grid. Three stacked blocks, alternating bg like the
   homepage's section rhythm (white -> black -> white).

   Every sentence of the source copy is still here verbatim —
   nothing removed, reworded, or replaced with tags/summaries.
   The container is a bento grid; hierarchy comes from cell size,
   color, and position — designing the order a human eye actually
   moves in, not from trimming words.

   NEW IN THIS PASS — explicit reading-order markers
   ------------------------------------------------------------
   The bento's size/contrast hierarchy already implies an order,
   but it's implicit: a visitor has to infer it. This pass makes
   it explicit with a small "01 / 02 / 03..." mono tag in the
   corner of every cell, styled like the eyebrow labels already
   used across the site (small, tracked-out, low-opacity mono
   type) so it reads as wayfinding chrome, not a fifth headline.
   Cell 1 in both the intro and the closing block additionally
   carries an sr-only "Start here:" cue for screen reader users,
   since the numbering itself is a visual-only affordance.

     1. Intro — reading order follows a Z-pattern, and tracks the
        source copy's own paragraph structure (01->02 finishes
        paragraph 1 before 03->04 starts paragraph 2):
          01 — top-left, biggest, highest-contrast cell (solid
               purple-secondary): paragraph 1's opening sentence,
               where a scanning eye always lands first.
          02 — top-right, quiet detail cell: paragraph 1's second
               sentence (the industries + service list) — completes
               the first idea before a new one starts.
          03 — bottom-right, small dark cell: paragraph 2's opening
               hook line. Dark/punchy on purpose — a new paragraph
               is a new idea, so it gets the attention-grabbing
               treatment instead of the "detail" cell's here.
          04 — bottom, full-width quiet cell: paragraph 2's closing
               sentence, the eye's last stop.
        Flat corners, hairline (1px) gaps between cells — matches
        Strategy.tsx's own "flat-cornered... rather than a rounded
        card" convention.

     2. Stats — unchanged: already a scannable data grid (large
        number / small label), the same underlying idea as a
        bento cell. No reading-order tag needed — a stat grid is
        scanned, not read in sequence.

     3. Closing — same bento + numbering logic at a smaller scale:
          01 — the claim, large and high-contrast.
          02 — the explanation, quieter, read second.
          03 — the closing CTA line + "Book a Strategy Call" button,
               in its own full-width high-contrast cell so the
               action step reads as visually distinct from the two
               "read" cells above it, not just another paragraph.
               Source copy links this button to
               /services/#book-now, but no #book-now anchor exists
               anywhere in this codebase — nothing on the services
               page (or elsewhere) has that id. Pointed it at
               /contact (the site's existing booking/contact flow)
               instead of shipping a dead link. Swap the href if a
               #book-now section gets added later.

   No tag/pill lists. Every word lives in exactly one place: its
   sentence, inside its cell.

   NEW IN THIS PASS — image cell (placeholder, pending real asset)
   ------------------------------------------------------------
   Added a decorative image strip between cell 01 and the stacked
   text column, to answer "make it feel alive" without touching any
   copy. Cell 01 narrowed from 7 to 5 cols, image takes 2, right
   text column stays 5 (5+2+5=12, still fills both grid rows evenly).
   No OrderTag on it — it's not part of the reading order, purely a
   visual break. Currently pointed at an existing repo photo
   (/approach/technico-step-1.jpg) as a placeholder so it renders as
   something real rather than a broken image — swap `src` for
   whatever final image gets picked. Hidden below `md` rather than
   squeezed into a sliver on mobile/tablet.

   NEW IN THIS PASS — full-bleed cells
   ------------------------------------------------------------
   Both bento blocks used to sit inside the shared mx-auto max-w-6xl
   container, same as every other section. That's fine for text, but
   it meant the purple/dark/light cell *backgrounds* stopped short of
   the viewport edge on anything wider than ~1152px, leaving a
   visible strip of the section's plain white-bg on both sides —
   looks like a mistake, not a margin. Both grids are now full-bleed
   (no width cap on the wrapper), so color reaches the true edge like
   the hero backdrop above them already does. Each cell's text keeps
   its own max-w so lines don't run uncomfortably long on very wide
   monitors even though the color behind them now does.
   ================================================================ */

const STATS = [
  { value: "1.37M", label: "Employer Businesses In Canada" },
  { value: "$21.1B", label: "Canadian Digital Advertising Market" },
  { value: "+16%", label: "Digital Ad Market Growth In 2025" },
  {
    value: "#1",
    label: "Search Remains Canada\u2019s Largest Digital Ad Category",
  },
] as const;

/** Small "read this Nth" corner tag — the explicit reading-order cue. */
function OrderTag({
  n,
  tone = "light",
}: {
  n: string;
  tone?: "light" | "dark";
}) {
  return (
    <span
      aria-hidden="true"
      className={`pointer-events-none absolute top-4 left-4 font-mono text-[10px] tracking-[0.2em] select-none sm:top-5 sm:left-5 ${
        tone === "light" ? "text-white/40" : "text-black-text/30"
      }`}
    >
      {n}
    </span>
  );
}

export default function ServicesMarketOverview() {
  return (
    <>
      {/* Intro */}
      <section className="bg-white-bg">
        {/* Full-bleed on purpose: this used to sit inside the shared
            mx-auto max-w-6xl container like every other section, which
            meant on any screen wider than ~1152px the purple/dark/light
            cell backgrounds stopped short of the viewport edge, leaving
            a visible band of the section's plain white-bg on both
            sides. Dropping the width cap here lets the cells' color
            reach the true edge — matches the hero backdrop above it,
            which is already edge-to-edge. Each cell keeps its own
            max-w on the text itself (below) so lines don't stretch
            uncomfortably long on very wide screens even though the
            color now does. */}
        <div className="pb-20 sm:pb-24 md:pb-28">
          <div className="grid grid-cols-1 gap-px bg-black-text/10 sm:grid-cols-2 md:grid-cols-12 md:grid-rows-2">
            {/* Cell 1 — biggest, highest contrast: first thing the eye hits.
                Narrowed from 7 -> 5 cols to make room for the image strip
                next to it (below) — text still gets its own max-w-2xl so
                the narrower column doesn't force awkward line breaks. */}
            <div className="relative flex flex-col justify-center bg-purple-secondary px-8 py-12 sm:col-span-2 sm:px-10 sm:py-14 md:col-span-5 md:row-span-2 md:px-12 md:py-16 lg:px-16">
              <OrderTag n="01" tone="light" />
              <div className="max-w-2xl">
                <span className="mb-5 block font-mono text-xs tracking-[0.14em] text-white/60 uppercase sm:text-sm">
                  What We Do
                </span>
                <p className="font-mono text-lg leading-relaxed tracking-wide text-white uppercase text-pretty sm:text-2xl md:text-[26px]">
                  <span className="sr-only">Start here: </span>
                  Technico Digital Solutions provides{" "}
                  <Link
                    href="/services"
                    className="underline decoration-1 underline-offset-4 hover:text-white/80"
                  >
                    digital marketing services
                  </Link>{" "}
                  for businesses seeking to improve search visibility, reach
                  qualified audiences, generate leads, and convert more online
                  interactions into customers.
                </p>
              </div>
            </div>

            {/* PLACEHOLDER IMAGE CELL — decorative only, no text, no
                OrderTag (it isn't part of the reading order). Reusing
                an existing photo from the repo (/approach/technico-step-1.jpg)
                just so this renders as something real when you check it —
                swap `src` below for whatever image you actually pick. Sits
                full-height between cell 01 and the stacked text column so
                it reads as a visual pause, not competing with either. Only
                shown from md up; on mobile/tablet it's dropped rather than
                squeezed into an awkward sliver (see hidden md:block). */}
            <div className="relative hidden overflow-hidden md:col-span-2 md:row-span-2 md:block">
              <Image
                src="/approach/technico-step-1.jpg"
                alt=""
                fill
                sizes="(min-width: 768px) 16vw, 0px"
                className="object-cover"
              />
            </div>

            {/* Cell 2 — second stop: finishes paragraph 1 (the industries +
                service list sentence), so 01->02 completes one idea before
                03 starts the next. */}
            <div className="relative flex items-center bg-[#f3f4ee] px-8 py-12 sm:px-10 sm:py-14 md:col-span-5 md:px-12 md:py-14 lg:px-14">
              <OrderTag n="02" tone="dark" />
              <p className="max-w-lg font-mono text-sm leading-loose tracking-wide text-black-text/60 uppercase text-pretty sm:text-base">
                Our digital experts support businesses across healthcare and
                dental, legal services, automotive, solar and renewable energy,
                construction, electrical, home improvement, and other local
                service industries through SEO, paid advertising, web design and
                development, content, and digital campaigns built around
                measurable business goals.
              </p>
            </div>

            {/* Cell 3 — third stop: opens paragraph 2, the punchy hook line,
                dark cell signals "new idea starting here". */}
            <div className="relative flex items-center bg-black-bg px-8 py-12 sm:px-10 sm:py-14 md:col-span-5 md:px-12 md:py-14 lg:px-14">
              <OrderTag n="03" tone="light" />
              <p className="max-w-lg font-mono text-base leading-relaxed tracking-wide text-white uppercase text-pretty sm:text-lg">
                You don&rsquo;t have to rely on just one marketing channel to
                grow your business.
              </p>
            </div>
          </div>

          {/* Cell 4 — last stop: the how-it-comes-together sentence. */}
          <div className="relative mt-px bg-[#f3f4ee] px-8 py-12 sm:px-10 sm:py-14 md:px-12 md:py-14">
            <OrderTag n="04" tone="dark" />
            <p className="mx-auto max-w-3xl font-mono text-sm leading-loose tracking-wide text-black-text/60 uppercase text-pretty sm:text-center sm:text-base">
              We look at where your customers are searching, what they see when
              they land on your website, and how SEO, paid ads, content, social
              media, and email can work together to bring in leads and turn more
              of those leads into customers.
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-black-bg">
        <div className="mx-auto max-w-6xl px-6 py-20 sm:py-24 md:py-28">
          <div className="flex items-center justify-center gap-2.5">
            <span className="h-2.5 w-2.5 shrink-0 bg-white" />
            <span className="font-mono text-xs tracking-[0.14em] text-white/70 uppercase text-balance sm:text-sm">
              The Canadian Market
            </span>
          </div>

          <TextRevealBlock
            as="h2"
            lines={[
              "Canadian Businesses Are Competing",
              "in a Digital-First Market",
            ]}
            className="mx-auto mt-6 max-w-3xl text-center text-[2rem] leading-[1.2] font-normal tracking-tight text-white sm:mt-7 sm:text-[42px] sm:leading-[1.15] sm:tracking-[-1.5px] md:text-[50px] md:leading-[1.12] md:tracking-[-2px]"
            scrollTrigger
          />

          <div className="mt-16 grid grid-cols-2 gap-x-8 gap-y-12 sm:mt-20 md:grid-cols-4 md:gap-6 md:divide-x md:divide-white/10">
            {STATS.map((stat) => (
              <div
                key={stat.label}
                className="md:px-6 md:first:pl-0 md:last:pr-0"
              >
                <p className="text-center text-4xl font-normal tracking-tight text-white sm:text-5xl">
                  {stat.value}
                </p>
                <p className="mt-3 text-center text-xs font-medium tracking-wide text-white/50 uppercase sm:mt-4 sm:text-sm">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Closing */}
      <section className="bg-white-bg">
        {/* Full-bleed for the same reason as the intro block above —
            see that section's comment. */}
        <div className="pt-20 pb-20 sm:pt-24 sm:pb-24 md:pt-28 md:pb-28">
          <div className="grid grid-cols-1 gap-px bg-black-text/10 md:grid-cols-12">
            {/* Cell 1 — the claim, large and high-contrast. */}
            <div className="relative flex items-center bg-purple-secondary px-8 py-12 sm:px-10 sm:py-14 md:col-span-7 md:px-12 md:py-16 lg:px-16">
              <OrderTag n="01" tone="light" />
              <p className="max-w-2xl font-mono text-lg leading-relaxed tracking-wide text-white uppercase text-pretty sm:text-xl md:text-2xl">
                <span className="sr-only">Start here: </span>A website and a few
                social media accounts can give your business an online presence,
                but that doesn&rsquo;t automatically bring in customers,
                especially in a competitive market like Vancouver.
              </p>
            </div>

            {/* Cell 2 — the explanation, quieter, read second. */}
            <div className="relative flex items-center bg-[#f3f4ee] px-8 py-12 sm:px-10 sm:py-14 md:col-span-5 md:px-12 md:py-16 lg:px-14">
              <OrderTag n="02" tone="dark" />
              <p className="max-w-lg font-mono text-sm leading-loose tracking-wide text-black-text/60 uppercase text-pretty sm:text-base">
                That&rsquo;s where the digital marketers at Technico Digital
                Solutions come in. We look at how customers find your business,
                what happens when they reach your website, and where potential
                leads drop off. SEO, paid ads, content, and social media are
                then brought together to help local businesses like yours
                generate qualified leads, ecommerce stores attract more
                customers, and growing brands reach a wider audience across
                Canada.
              </p>
            </div>
          </div>

          {/* Cell 3 — the action step: CTA line + button, deliberately
              set apart (full-width, high-contrast) from the two "read"
              cells above so it reads as "now act", not "keep reading". */}
          <div className="relative mt-px flex flex-col items-center gap-8 bg-black-bg px-8 py-12 text-center sm:px-10 sm:py-14 md:px-12 md:py-16">
            <OrderTag n="03" tone="light" />
            <p className="max-w-xl font-mono text-sm leading-loose tracking-wide text-white/70 uppercase text-pretty sm:text-base">
              We go the extra mile to help you fulfill your business plans with
              targeted digital marketing strategies. Partner with us today and
              see competitive results.
            </p>
            <div className="w-full max-w-xs sm:w-auto">
              <GlossyButton to="/contact">Book a Strategy Call</GlossyButton>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
