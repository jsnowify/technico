import ServiceGridCorners from "./ServiceGridCorners";

interface ProcessStep {
  title: string;
  description: string;
}

interface ServicesProcessProps {
  eyebrow: string;
  headline: string;
  paragraph: string;
  steps: ProcessStep[];
  descriptionLayout?: "centered" | "edge";
}

export default function ServicesProcess({
  eyebrow,
  headline,
  paragraph,
  steps,
  descriptionLayout = "centered",
}: ServicesProcessProps) {
  return (
    <section className="bg-black-bg">
      <header className="grid grid-cols-1 gap-7 md:grid-cols-[minmax(0,1.15fr)_minmax(280px,0.85fr)] md:gap-16">
        <div>
          <p className="flex items-center gap-3 font-mono text-xs tracking-[0.05em] text-white/55 uppercase">
            <span aria-hidden="true" className="h-px w-9 bg-purple-accent" />
            {eyebrow}
          </p>
          <h2 className="mt-5 max-w-[21ch] font-medium tracking-heading text-white">
            {headline}
          </h2>
        </div>

        <p className="body-copy max-w-[54ch] leading-[1.62] text-white/65 md:pt-7">
          {paragraph}
        </p>
      </header>

      <ol className="relative mt-12 border border-white/18 sm:mt-16">
        <ServiceGridCorners />

        {steps.map((step, index) => (
          <li
            key={`${step.title}-${index}`}
            className="group relative grid grid-cols-1 overflow-hidden border-b border-white/18 last:border-b-0 md:grid-cols-[29%_71%]"
          >
            <span
              aria-hidden="true"
              className="absolute inset-y-0 left-0 w-0 bg-purple-accent/10 transition-[width] duration-700 ease-[cubic-bezier(0.22,0.8,0.22,1)] group-hover:w-full"
            />

            <div className="relative flex min-h-24 items-start justify-between gap-5 border-b border-white/18 p-5 md:min-h-36 md:border-r md:border-b-0 md:p-7">
              <span className="font-mono text-xs tracking-[0.06em] text-purple-accent">
                {String(index + 1).padStart(2, "0")}
              </span>
              <span aria-hidden="true" className="font-mono text-white/30">
                —
              </span>
            </div>

            <div
              className={`relative grid min-h-36 grid-cols-1 gap-5 p-5 sm:p-7 md:grid-cols-[minmax(180px,0.45fr)_minmax(0,1fr)] md:items-center md:p-9 ${
                index % 2 === 1 ? "md:[&>h3]:order-2" : ""
              }`}
            >
              <h3 className="text-[clamp(1.5rem,2.5vw,2.25rem)] leading-[1.05] font-medium text-white transition-transform duration-500 ease-[cubic-bezier(0.22,0.8,0.22,1)] group-hover:translate-x-2">
                {step.title}
              </h3>
              <p
                className={`body-copy max-w-[60ch] leading-[1.62] text-white/62 ${
                  descriptionLayout === "centered" ? "md:text-center" : ""
                }`}
              >
                {step.description}
              </p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
