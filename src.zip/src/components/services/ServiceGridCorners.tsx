interface ServiceGridCornersProps {
  className?: string;
}

/** Decorative registration marks shared by service-detail grids. */
export default function ServiceGridCorners({
  className = "text-purple-accent",
}: ServiceGridCornersProps) {
  const base = `pointer-events-none absolute z-10 grid h-4 w-4 place-items-center bg-black-bg font-mono text-sm leading-none ${className}`;

  return (
    <>
      <span aria-hidden="true" className={`${base} -top-2 -left-2`}>
        +
      </span>
      <span aria-hidden="true" className={`${base} -top-2 -right-2`}>
        +
      </span>
      <span aria-hidden="true" className={`${base} -bottom-2 -left-2`}>
        +
      </span>
      <span aria-hidden="true" className={`${base} -right-2 -bottom-2`}>
        +
      </span>
    </>
  );
}
