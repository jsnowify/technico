"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import styles from "./ServiceSectionFrame.module.css";

const SECTION_LABELS: Record<string, string> = {
  hero: "Service overview",
  cta: "Next move",
  highlights: "Capabilities",
  conversion: "Performance system",
  insights: "Market intelligence",
  results: "Measured outcomes",
  contentPillars: "Content pillars",
  pillarCards: "Core framework",
  growBusiness: "Growth system",
  comparison: "Side by side",
  marqueeCta: "Open channel",
  featuresSplit: "Deliverables",
  featureCard: "Feature focus",
  imageStatement: "Design statement",
  process: "Working process",
  trustedBy: "Selected partners",
  techStack: "Tools and work",
  introPanel: "The opportunity",
  faq: "Questions / answers",
};

interface ServiceSectionFrameProps {
  children: ReactNode;
  index: number;
  type: string;
  accent: "pink" | "purple";
}

export default function ServiceSectionFrame({
  children,
  index,
  type,
  accent,
}: ServiceSectionFrameProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVisible(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        setVisible(true);
        observer.disconnect();
      },
      { rootMargin: "0px 0px -10%", threshold: 0.08 },
    );

    observer.observe(root);
    return () => observer.disconnect();
  }, []);

  const number = String(index + 1).padStart(2, "0");

  return (
    <div
      ref={rootRef}
      className={styles.root}
      data-visible={visible}
      data-type={type}
      data-accent={accent}
    >
      <div className={styles.rule} aria-hidden="true" />

      <div className={styles.inner}>
        <div className={styles.meta} aria-hidden="true">
          <span className={styles.metaLabel}>
            <span className={styles.metaDash} />
            <span>Services</span>
          </span>
          <span className={styles.metaType}>
            {SECTION_LABELS[type] ?? type}
          </span>
          <span className={styles.metaIndex}>{number} / +</span>
        </div>

        <div className={styles.body}>
          <span
            className={`${styles.corner} ${styles.cornerTopLeft}`}
            aria-hidden="true"
          >
            +
          </span>
          <span
            className={`${styles.corner} ${styles.cornerTopRight}`}
            aria-hidden="true"
          >
            +
          </span>
          <span
            className={`${styles.corner} ${styles.cornerBottomLeft}`}
            aria-hidden="true"
          >
            +
          </span>
          <span
            className={`${styles.corner} ${styles.cornerBottomRight}`}
            aria-hidden="true"
          >
            +
          </span>

          <div className={styles.content}>{children}</div>
        </div>
      </div>
    </div>
  );
}
